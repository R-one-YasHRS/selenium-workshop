<?php

session_start();
echo($_SESSION['username']."<br>");
echo($_SESSION['email']."<br>");

?>